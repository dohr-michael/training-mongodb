package main

import (
	"github.foyer.lu/meo-apps/spa-server/cmd"
)

func main() {
	cmd.Execute()
}
