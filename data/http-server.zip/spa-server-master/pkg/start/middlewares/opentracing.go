package middlewares

import (
	"fmt"
	ot "github.com/opentracing/opentracing-go"
	"github.com/opentracing/opentracing-go/ext"
	"net/http"
)

func NewOpentracingMiddleware(name string) func(http.Handler) http.Handler {
	return func(next http.Handler) http.Handler {
		fn := func(w http.ResponseWriter, r *http.Request) {
			//route := chi.RouteContext(r.Context()).RoutePath
			wireContext, _ := ot.GlobalTracer().Extract(ot.HTTPHeaders, ot.HTTPHeadersCarrier(r.Header))
			serverSpan := ot.GlobalTracer().StartSpan(name, ext.RPCServerOption(wireContext))

			operationName := ""
			if r.URL.Host != "" {
				operationName = fmt.Sprintf("%s%s", r.URL.Host, r.URL.Path)
			} else {
				operationName = fmt.Sprintf("%s%s", r.Host, r.URL.Path)
			}

			serverSpan.SetTag(string(ext.Component), "spa-server")
			serverSpan.SetTag(string(ext.SpanKind), string(ext.SpanKindRPCServerEnum))
			serverSpan.SetTag(string(ext.PeerHostname), r.Host)
			serverSpan.SetTag(string(ext.HTTPMethod), r.Method)
			serverSpan.SetTag(string(ext.HTTPUrl), r.URL.Path)
			serverSpan.SetOperationName(operationName)

			// TODO check that
			//if route != "" {
			//	serverSpan.SetTag("http.path_tpl", route)
			//}

			newRes := newWithStatusResponseWriter(w)
			newReq := r.WithContext(ot.ContextWithSpan(r.Context(), serverSpan))

			next.ServeHTTP(newRes, newReq)

			serverSpan.SetTag(string(ext.HTTPStatusCode), newRes.getStatus())
			if newRes.getStatus() >= 500 {
				serverSpan.SetTag(string(ext.Error), true)
			}

			_ = ot.GlobalTracer().Inject(serverSpan.Context(), ot.HTTPHeaders, ot.HTTPHeadersCarrier(newRes.Header()))
			serverSpan.Finish()

		}
		return http.HandlerFunc(fn)
	}
}
