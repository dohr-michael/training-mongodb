package middlewares

import (
	"net/http"
)

type withStatusResponseWriterWrapped interface {
	http.ResponseWriter
	getStatus() int
}

type withStatusResponseWriter struct {
	http.ResponseWriter
	status int
	length int
}

func (w *withStatusResponseWriter) getStatus() int { return w.status }

func (w *withStatusResponseWriter) WriteHeader(status int) {
	w.status = status
	w.ResponseWriter.WriteHeader(status)
}

func (w *withStatusResponseWriter) Write(b []byte) (int, error) {
	if w.status == 0 {
		w.status = 200
	}
	n, err := w.ResponseWriter.Write(b)
	w.length += n
	return n, err
}

func newWithStatusResponseWriter(base http.ResponseWriter) withStatusResponseWriterWrapped {
	p, ip := base.(http.Pusher)
	basic := &withStatusResponseWriter{ResponseWriter: base}
	if ip {
		return &struct {
			*withStatusResponseWriter
			http.Pusher
		}{withStatusResponseWriter: basic, Pusher: p}
	}
	return basic
}
