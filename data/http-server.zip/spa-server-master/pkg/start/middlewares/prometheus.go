package middlewares

import (
	"github.com/go-chi/chi/middleware"
	"github.com/prometheus/client_golang/prometheus"
	"net/http"
	"time"
)

var (
	dflBuckets = []float64{300, 1200, 5000}
)

const (
	reqsName    = "spa_server_requests_total"
	latencyName = "spa_server_request_duration_milliseconds"
)

type PrometheusMiddleware struct {
	reqs    *prometheus.CounterVec
	latency *prometheus.HistogramVec
}

func (c PrometheusMiddleware) handler(next http.Handler) http.Handler {
	fn := func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()
		ww := middleware.NewWrapResponseWriter(w, r.ProtoMajor)
		next.ServeHTTP(ww, r)
		c.reqs.WithLabelValues(http.StatusText(ww.Status())).Inc()
		c.latency.WithLabelValues(http.StatusText(ww.Status())).Observe(float64(time.Since(start).Nanoseconds()) / 1000000)
	}
	return http.HandlerFunc(fn)
}

func NewPrometheusMiddleware(name string, buckets ...float64) func(next http.Handler) http.Handler {
	var m PrometheusMiddleware
	m.reqs = prometheus.NewCounterVec(
		prometheus.CounterOpts{
			Name:        reqsName,
			Help:        "How many HTTP requests processed, partitioned by status code, method and HTTP path.",
			ConstLabels: prometheus.Labels{"service": name},
		},
		[]string{"code"},
	)

	prometheus.MustRegister(m.reqs)
	if len(buckets) == 0 {
		buckets = dflBuckets
	}
	m.latency = prometheus.NewHistogramVec(prometheus.HistogramOpts{
		Name:        latencyName,
		Help:        "How long it took to process the request, partitioned by status code, method and HTTP path.",
		ConstLabels: prometheus.Labels{"service": name},
		Buckets:     buckets,
	},
		[]string{"code"},
	)

	prometheus.MustRegister(m.latency)
	return m.handler

}