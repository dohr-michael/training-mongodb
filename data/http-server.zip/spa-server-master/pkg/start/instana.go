package start

import (
	"fmt"
	"strings"
)

type InstanaConfig struct {
	ApiKey             string
	BaseUrl            string
	WhitelistedOrigins []string
	IgnoreUrls         []string
}

const instanaNoopJs = "(function(){window['ineum']=function(){};})();"

func (c *InstanaConfig) ToJs() string {
	ineumRegEx := func(k string, r []string) string {
		if len(r) == 0 {
			return ""
		}
		return fmt.Sprintf("ineum('%s', [%s]);", k, strings.Join(r, ", "))
	}

	if c.ApiKey == "" {
		return instanaNoopJs
	}

	return fmt.Sprintf(`
(function(i,s,o,g,r,a,m){i['InstanaEumObject']=r;i[r]=i[r]||function(){
	(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();
	a=s.createElement(o),m=s.getElementsByTagName(o)[0];
	a.async=1;a.src=g;
	m.parentNode.insertBefore(a,m)
})(window,document,'script','%s/eum.min.js','ineum');
ineum('reportingUrl', '%s');
ineum('apiKey', '%s');
%s
%s
`, c.BaseUrl, c.BaseUrl, c.ApiKey, ineumRegEx("ignoreUrls", c.IgnoreUrls), ineumRegEx("whitelistedOrigins", c.WhitelistedOrigins))
}
