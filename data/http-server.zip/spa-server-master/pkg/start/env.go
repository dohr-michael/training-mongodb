package start

import (
	"github.foyer.lu/meo-apps/spa-server/config"
	"os"
	"strings"
	"time"
)

func NewEnvContext(overridden []string) *envContext {
	result := &envContext{
		publicEnv: make(map[string]string),
		Instana: &InstanaConfig{
			BaseUrl: "https://api.foyer.lu/instana",
		},
		NoCacheFiles: []string{"/index.html", "/@/metrics", "/@/health", "/@/info"},
		AppEnv: "unknown",
		AppName: "spa-server",
		AppVersion: config.Config.BuildVersion(),
		AppCommit: config.Config.BuildRevision(),
		AppBuildAt: config.Config.BuildTime(),
		AppStartedAt: time.Now().Format(time.RFC3339),
	}
	envItems := append(os.Environ(), overridden...)

	for _, i := range envItems {
		sep := strings.Index(i, "=")
		key := i[0:sep]
		value := i[sep+1:]
		if strings.HasPrefix(key, "SPA_CONFIG_") {
			result.publicEnv[strings.TrimPrefix(key, "SPA_CONFIG_")] = value
		} else {
			if len(strings.TrimSpace(value)) == 0 {
				continue
			}
			switch key {
			case "INSTANA_API_KEY":
				result.Instana.ApiKey = value
			case "INSTANA_BASE_URL":
				result.Instana.BaseUrl = value
			case "INSTANA_WHITELISTED_ORIGINS":
				items := strings.Split(value, ",")
				for _, item := range items {
					if s := strings.TrimSpace(item); len(s) > 0 {
						result.Instana.WhitelistedOrigins = append(result.Instana.WhitelistedOrigins, s)
					}
				}
			case "INSTANA_IGNORE_URLS":
				items := strings.Split(value, ",")
				for _, item := range items {
					if s := strings.TrimSpace(item); len(s) > 0 {
						result.Instana.IgnoreUrls = append(result.Instana.IgnoreUrls, s)
					}
				}
			case "NO_CACHE_FILES":
				items := strings.Split(value, ",")
				for _, item := range items {
					if s := strings.TrimSpace(item); len(s) > 0 {
						result.NoCacheFiles = append(result.NoCacheFiles, s)
					}
				}
			case "APP_ENV", "ENV", "PLAY_ID":
				result.AppEnv = value
			case "APP_NAME":
				result.AppName = value
			case "APP_COMMIT":
				result.AppCommit = value
			case "APP_BUILD_AT":
				result.AppBuildAt = value
			case "APP_VERSION":
				result.AppVersion = value
			}
		}
	}

	return result
}

type envContext struct {
	publicEnv    map[string]string
	Instana      *InstanaConfig
	NoCacheFiles []string
	AppEnv       string
	AppName      string
	AppBuildAt   string
	AppStartedAt string
	AppVersion   string
	AppCommit    string
}

func (c *envContext) PublicEnv() map[string]string {
	return c.publicEnv
}
