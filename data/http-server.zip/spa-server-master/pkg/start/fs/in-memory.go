package fs

import (
	"net/http"
	"os"
	"sync"
	"time"
)

func NewFS() *fs {
	return &fs{
		files: make(map[string]http.File),
	}
}

type fs struct {
	files map[string]http.File
}

func (fs *fs) AddFile(name string, val []byte, modTime time.Time) http.File {
	file := &InMemoryFile{
		at:      0,
		Name:    name,
		data:    val,
		fs:      fs,
		modTime: modTime,
	}
	fs.files[name] = file
	return file
}

func (fs *fs) Open(name string) (http.File, error) {
	if f, ok := fs.files[name]; ok {
		return f, nil
	}
	return nil, os.ErrNotExist
}

type InMemoryFile struct {
	sync.Mutex
	at      int64
	modTime time.Time
	Name    string
	data    []byte
	fs      *fs
}

func (f *InMemoryFile) GetData() []byte {
	f.Lock()
	defer f.Unlock()
	return append([]byte{}, f.data...)
}

func (*InMemoryFile) Close() error {
	return nil
}

func (f *InMemoryFile) Read(b []byte) (n int, err error) {
	f.Lock()
	defer f.Unlock()
	i := 0
	for f.at < int64(len(f.data)) && i < len(b) {
		b[i] = f.data[f.at]
		i++
		f.at++
	}
	return i, nil
}

func (f *InMemoryFile) Seek(offset int64, whence int) (int64, error) {
	f.Lock()
	defer f.Unlock()
	switch whence {
	case 0:
		f.at = offset
	case 1:
		f.at += offset
	case 2:
		f.at = int64(len(f.data)) + offset
	}
	return f.at, nil
}

func (f *InMemoryFile) Readdir(count int) ([]os.FileInfo, error) {
	f.Lock()
	defer f.Unlock()
	res := make([]os.FileInfo, len(f.fs.files))
	i := 0
	for _, file := range f.fs.files {
		res[i], _ = file.Stat()
		i++
	}
	return res, nil
}

func (f *InMemoryFile) Stat() (os.FileInfo, error) {
	f.Lock()
	defer f.Unlock()
	return &InMemoryFileInfo{f}, nil
}

type InMemoryFileInfo struct {
	file *InMemoryFile
}

// Implements os.FileInfo
func (s *InMemoryFileInfo) Name() string       { return s.file.Name }
func (s *InMemoryFileInfo) Size() int64        { return int64(len(s.file.data)) }
func (s *InMemoryFileInfo) Mode() os.FileMode  { return os.ModeTemporary }
func (s *InMemoryFileInfo) ModTime() time.Time { return s.file.modTime }
func (s *InMemoryFileInfo) IsDir() bool        { return false }
func (s *InMemoryFileInfo) Sys() interface{}   { return nil }
