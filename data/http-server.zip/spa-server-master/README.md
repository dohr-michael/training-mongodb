spa-server
===========


- Commands (from Magefile)
    - Run unit test : `mage test` 
    - Build locally : `mage build` 
    - Snapshot release (with container generation): `mage snapshot` 
    - Release (if tag is specify): `mage release`
- Instal dependencies
```
go mod download
```
- Run project
```
go run main.go start
```
- Hot Reload
```
go get github.com/codegangsta/gin
gin --appPort 8080 --buildArgs main.go -i run start
```

- Needs
    - Replacement in the project (in order):
        - `spa-server` by your project name
        - `github.foyer.lu/meo-apps` by your github / git path / by your go package root.
        - `jdrbahamut` by your docker registry organization.
    - environment variables
        - GITHUB_TOKEN
    - Docker registry authentication
- Release Generate :
    - Binaries
        - darwin_amd64
        - darwin_386
        - linux_amd64
        - linux_arm64
        - linux_386
        - windows_amd64
        - windows_386
    - Docker Container
        - linux_amd64
    - Github release
    - Homebrew Tap
    - Scoop recipe
